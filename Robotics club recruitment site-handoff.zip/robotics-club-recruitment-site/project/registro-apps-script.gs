// Arbi · Inscripciones → Google Sheets (v2: bloqueo de duplicados reforzado)
// Después de pegar este código: Implementar → Gestionar implementaciones → ✏️ →
// Versión: "Nueva versión" → Implementar. (Guardar NO actualiza la versión publicada.)

const SHEET_NAME = 'Inscripciones';
const HEADERS = ['Fecha', 'Nombre y Apellido', 'CI', 'Carnet', 'Correo institucional', 'Teléfono', 'Carrera',
  'Selección deportiva', 'Programa socioeconómico', 'Intereses', 'Trimestre', 'Experiencia previa',
  'Detalle experiencia', 'Herramientas'];

// Normaliza: solo letras y números, sin ceros a la izquierda. "V-30.123.456" = "30123456".
function norm(s) {
  return String(s == null ? '' : s).toUpperCase().replace(/^[VEJP]-?/, '').replace(/[^0-9A-Z]/g, '').replace(/^0+/, '');
}

function getSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) sh = ss.insertSheet(SHEET_NAME);
  if (sh.getLastRow() === 0) { sh.appendRow(HEADERS); sh.setFrozenRows(1); }
  return sh;
}

// Busca las columnas por nombre del encabezado, así funciona aunque se muevan columnas.
function isDuplicate(sh, ci, carnet) {
  const last = sh.getLastRow();
  if (last < 2) return false;
  const head = sh.getRange(1, 1, 1, sh.getLastColumn()).getDisplayValues()[0].map(h => h.trim().toLowerCase());
  const ciCol = head.indexOf('ci'), caCol = head.indexOf('carnet');
  const data = sh.getRange(2, 1, last - 1, sh.getLastColumn()).getDisplayValues();
  const nCi = norm(ci), nCa = norm(carnet);
  return data.some(r =>
    (nCi && ciCol > -1 && norm(r[ciCol]) === nCi) ||
    (nCa && caCol > -1 && norm(r[caCol]) === nCa));
}

// Verificación previa (paso 2 del formulario)
function doGet(e) {
  const p = (e && e.parameter) || {};
  if (!p.check) return json({ result: 'ok' });
  const sh = getSheet();
  return json({ result: isDuplicate(sh, p.ci, p.carnet) ? 'duplicate' : 'ok' });
}

// Registro (se vuelve a verificar aquí, con bloqueo, para evitar envíos simultáneos)
function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const d = JSON.parse(e.postData.contents);
    if (!norm(d.ci) || !norm(d.carnet)) return json({ result: 'error', message: 'CI y carnet son obligatorios' });
    const sh = getSheet();
    if (isDuplicate(sh, d.ci, d.carnet)) return json({ result: 'duplicate' });
    sh.appendRow([new Date(), d.nombre, "'" + d.ci, "'" + d.carnet, d.correo, "'" + d.telefono, d.carrera,
      d.seleccion || 'No', d.programa || 'No', d.intereses, d.trimestre ? d.trimestre + 'º' : '',
      d.experiencia === 'si' ? 'Sí' : d.experiencia === 'no' ? 'No' : '', d.detalle, d.herramientas]);
    SpreadsheetApp.flush();
    return json({ result: 'ok' });
  } catch (err) {
    return json({ result: 'error', message: String(err) });
  } finally {
    lock.releaseLock();
  }
}

function json(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}
